WorkAdventure Woka bundle for Senior Advisor (exec-advisor).

Contains six category walk sheets (96×128, 3 frames × 4 directions).
Direction order: down, left, right, up.

NOTE: idle / talk / approve are NOT part of the WorkAdventure Woka
format. Use the FundExecs extended bundle for those states.