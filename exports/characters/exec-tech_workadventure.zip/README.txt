WorkAdventure Woka bundle for Chief Technology Officer (exec-tech).

Contains six category walk sheets (96×128, 3 frames × 4 directions).
Direction order: down, left, right, up.

NOTE: idle / talk / approve are NOT part of the WorkAdventure Woka
format. Use the FundExecs extended bundle for those states.