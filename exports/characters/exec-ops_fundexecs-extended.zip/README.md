# FundExecs Extended Bundle — Head of Operations

Directory layout:
- `native/` — 32px sprite sheets for idle, walk, talk, approve
- `native/layers/` — per-WorkAdventure-category walk breakdown
- `review-8x/` — exact 8× nearest-neighbor enlargements
- `pbr-showcase/` — material metadata (PBR is a preview layer, not runtime art)

Sheet dimensions (per manifest):
- idle: 64×128
- walk: 96×128
- talk: 128×128
- approve: 128×128

These extended states require FundExecs / custom runtime support;
they are beyond the standard WorkAdventure Woka walk sheet.